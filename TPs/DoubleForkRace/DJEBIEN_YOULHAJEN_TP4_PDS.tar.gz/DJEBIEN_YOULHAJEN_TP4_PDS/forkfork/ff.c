#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
#include "forkfork.h"

int
main()
{
forkfork(f,(void *)0);
return 0;
}
