README : 

// Auteur : DJEBIEN Tarik & YOULHAJEN Jamal dine
// Date    : 31 janvier 2010
// Objet  : exercices de la feuille de TD/TP gestion de processus

Ci-Joint le TP numero 4 de Programmation des systèmes :

Arborescence de l'archive Tarik_Djebien_GROUPE4.tar.gz :
    |
    |_____README.txt
    |_____forkfork/ forkfork.h forkfork.c ff.c ff.txt 
    |_____race/ race.c race.txt
    
Remarques:

Tout est fonctionnel

Pour les commentaires :

tarik.djebien@etudiant.univ-lille1.fr
jamaldine.youlhajen@etudiant.univ-lille1.fr

Cordialement.
