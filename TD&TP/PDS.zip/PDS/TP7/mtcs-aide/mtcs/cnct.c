/* ------------------------------
   $Id: cnct.c,v 1.3 2007/04/04 15:18:50 marquet Exp $
   ------------------------------------------------------------

   mtcs - a multithreaded chat serveur
   Philippe Marquet, Apr 2005

   Gestion de la connexion d'un client par un thread
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <assert.h>
#include <pthread.h>
#include <signal.h>
#include <sys/wait.h>
#include <errno.h>

#include "config.h"
#include "tools.h"
#include "cnct.h"
#include "stat.h"

/* Gestion des sockets */
static int sockets[MAX_CONNECTION]; /* tableau initialis� a zero */
pthread_mutex_t sockets_lock = PTHREAD_MUTEX_INITIALIZER;
static STAT* theStats;


static void
add_socket(int fd)
{
    int i;
    
    pgrs_in();

    pthread_mutex_lock(&sockets_lock);
    for (i=0; i<MAX_CONNECTION; i++) {
	if (sockets[i] == 0) {
	    sockets[i] = fd;
	    break;
	}
    }
    pthread_mutex_unlock(&sockets_lock);



    assert(i!=MAX_CONNECTION);
    pgrs_out();
}

static void
del_socket(int fd)
{
    int i;
    
    pgrs_in();

    pthread_mutex_lock(&sockets_lock);
    for (i=0; i<MAX_CONNECTION; i++) {
	if (sockets[i] == fd) {
	    sockets[i] = 0;
	    break;
	}
    }
    pthread_mutex_unlock(&sockets_lock);

    stat_removeClient(theStats);

    assert(i!=MAX_CONNECTION);
    pgrs_out();
}

/* Un client  */
static void *
repeater(void * sckt1)
{
    char buf[MAX_BUFFER];
    int nbc, i, sckt, nblignes;
    const char WELCOME[] = "mtcs : bienvenu\n";

    pgrs_in();
    sckt = (int) sckt1;
    write(sckt, WELCOME, strlen(WELCOME));

    pgrs("enregistrement d'une socket");
    add_socket(sckt);
    stat_addClient(theStats);
    
    while (1) {
	pgrs("attente read");
	nbc = read(sckt, buf, MAX_BUFFER);
	if (nbc <= 0) {
	    pgrs("fin lecture client");
	    pgrs("desenregistrement d'une socket");
	    del_socket(sckt);
	    close(sckt);
            pgrs_out();
	    return (void *) 0;
	}
	pgrs("boucle ecriture");
	if (nbc%80==0)
		nblignes = nbc/80;
	else
		nblignes = nbc/80+1;
	stat_addLignesEnvoyees(theStats,nblignes);
        pthread_mutex_lock(&sockets_lock);
	for(i=0; i<MAX_CONNECTION; i++)
	    if (sockets[i])
		write(sockets[i], buf, nbc);
		stat_addLignesRecues(theStats,nblignes);
        pthread_mutex_unlock(&sockets_lock);
	pgrs("fin boucle ecriture");

    }
}

void
sigusr1_handler() 
{
	print_stat(theStats);

}

/*
 * Signal - wrapper for the sigaction function
 */
void
signal_wrapper() 
{
	struct sigaction action;
	action.sa_handler=sigusr1_handler;
	sigemptyset(&action.sa_mask);
	action.sa_flags=SA_RESTART;
	if (sigaction(SIGUSR1,&action,0)<0)
		perror("signal_wrapper error");

}

void a_faire_une_fois () {
	theStats = initStat();
	signal_wrapper();
}

/* Cr�ation d'un client */
/* Version stupide. Pas de creation de thread, 
   Le serveur ne peut plus accepter de connexion car il g�re
   l'interaction avec le premier client. 
*/
int
manage_cnct(int fd)
{    
    pthread_t tid;
    static pthread_once_t tid2 = PTHREAD_ONCE_INIT;
    int status;

    pgrs_in();
	
    status = pthread_once(&tid2,a_faire_une_fois);
    status = pthread_create (&tid, NULL, repeater, (void *) fd);
    if (status) {
	perror ("creation de thread impossible\n");
	exit(EXIT_FAILURE);
    }

    pgrs_out();
    return 0;
}
