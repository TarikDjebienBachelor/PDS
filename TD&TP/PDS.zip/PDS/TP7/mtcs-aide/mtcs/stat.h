

struct struct_stat {
	int fd;
	int clients;
	int lignes_recues;
	int lignes_envoyees;
	int max_clients_t;
	int max_lignes_recues;
	int max_lignes_envoyees;
};

typedef struct struct_stat STAT;

extern STAT* initStat();
extern void stat_addClient (STAT * theStats);
extern void stat_removeClient (STAT * theStats);
extern void stat_addLignesRecues (STAT * theStats,int n);
extern void stat_addLignesEnvoyees (STAT * theStats,int n);
extern void print_stat(STAT * theStats);
