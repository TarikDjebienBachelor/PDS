#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <assert.h>
#include <pthread.h>

#include "config.h"
#include "tools.h"
#include "cnct.h"
#include "stat.h"

pthread_mutex_t stats_lock = PTHREAD_MUTEX_INITIALIZER;

STAT *
initStat() {
	STAT * theStats;
	theStats = malloc (sizeof(STAT));
	theStats->clients = 0;
	theStats->lignes_recues = 0;
	theStats->lignes_envoyees = 0;
	theStats->max_clients_t = 0;
	theStats->max_lignes_recues = 0;
	theStats->max_lignes_envoyees = 0;
	return theStats;
}

void
stat_addClient (STAT * theStats) {
    	pthread_mutex_lock(&stats_lock);
	theStats->clients++;
	if (theStats->max_clients_t < theStats->clients)
		theStats->max_clients_t = theStats->clients;
    	pthread_mutex_unlock(&stats_lock);
} 

void
stat_removeClient (STAT * theStats) {
    	pthread_mutex_lock(&stats_lock);
	theStats->clients--;
    	pthread_mutex_unlock(&stats_lock);
} 

void
stat_addLignesRecues (STAT * theStats, int n) {
    	pthread_mutex_lock(&stats_lock);
	theStats->lignes_recues+=n;
	if (theStats->max_lignes_recues < n)
		theStats->max_lignes_recues = n;
    	pthread_mutex_unlock(&stats_lock);
}

void
stat_addLignesEnvoyees (STAT * theStats, int n) {
    	pthread_mutex_lock(&stats_lock);
	theStats->lignes_envoyees+=n;
	if (theStats->max_lignes_envoyees < n)
		theStats->max_lignes_envoyees = n;
    	pthread_mutex_unlock(&stats_lock);
}


void 
print_stat (STAT * theStats) {
	printf("Nombre total de clients:                   %d\n",theStats->clients);
	printf("Nombre total de lignes reçues:             %d\n",theStats->lignes_recues);
	printf("Nombre total de lignes envoyees:           %d\n",theStats->lignes_envoyees);
	printf("Nombre maximal de clients à un instant t:  %d\n",theStats->max_clients_t);
	printf("Nombre maximal de lignes reçues:           %d\n",theStats->max_lignes_recues);
	printf("Nombre maximal de lignes envoyees:         %d\n\n",theStats->max_lignes_envoyees);
}







