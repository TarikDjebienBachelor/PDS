/* ------------------------------
   $Id: tools.c,v 1.2 2007/04/04 15:18:50 marquet Exp $
   ------------------------------------------------------------

   mtcs - a multithreaded chat serveur
   Philippe Marquet, Apr 2005

   Outils divers
*/

/*athor Mouttalib nassim*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#include "tools.h"

int verbose = 0;
/**

struct rec_mutex_s{
	pthread_mutex_lock rm_mutex;
	bool_t rm owned;
	unsigned rm_nlock;
	pthread_t rm_owner;
	pthread_cond_t rm_waiters;
};*/

void
nyi_(const char*funcname, const char *s)
{
    fprintf(stderr, "mtcs: (%s) %s not yet implemented, exiting\n",
	    funcname, s);
    exit(EXIT_FAILURE);
}

void
pgrs_(const char*funcname, const char *s)
{
    if (verbose)
	fprintf(stderr, "(%lu) %s(): %s\n",
		(unsigned long) pthread_self(), funcname, s);
}

/*void
rec_mutex_lock(rec_mutex_s *rm)
{
	while((rm->rm_owned) && (rm->rm_owner != pthread_self())){
		pthread_cond_wait(&(rm->rm_waiters),&(rm->rm_mutex));
		rm->rm_nlock++;
		rm->rm_owner = pthread_self();
		rm->rm_owned = TRUE;
		pthread_mutex_unlock(&(rm->rm_mutex));
	}
}

void
rec_mutex_unlock(rec_mutex_s *rm)
{
	pthread_mutex_lock(&(rm->rm_mutex));
	rm->rm_nlock--;
	if(rm->rm_nlock == 0){
		rm->rm_owned = FALSE;
		pthread_cond_signal(&(rm->rm_waiters));
	pthread_mutex_unlock(&(rm->rm_mutex));
}

*/
