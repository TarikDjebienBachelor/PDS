#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/types.h>
#include "forkfork.h"

void petit_fils(int i)
{
  pid_t ppid;
  printf("%d \n",i);
  sleep(2);
  ppid=getppid();
  printf("ppid:%d \n",ppid);
  exit(EXIT_SUCCESS);
}

void forkfork(func f,int i){
  pid_t pid;
  pid=fork();
  if(pid==0) {
      pid=fork();
      if(pid==0){
	  f(i);
	  exit(EXIT_SUCCESS);
      }else{
	  exit(EXIT_SUCCESS);
      }
  }else{
      wait((int *)0);
  }
  
}

int main(void)
{
  forkfork(petit_fils,100);
  getchar();
  printf("Le pere est toujours vivant \n");
 
  exit(EXIT_SUCCESS);
}
