#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/types.h>

void  compte(int numfils)
{
  int i;
 while(i<500000000) {
      i++;
 }
 
 while(i<500000000) {
      i++;
 }
}

int main (void)
{
  int numfils;
  pid_t pid;
  int i=0;
  
  while(i<10){
      pid=fork();
      if(pid==-1){
	  perror("Erreur fork");
      }
      if(pid==0){
	  compte(i);
	  exit(i);
      }
     i++;
  }
  printf("classement : \n");
  for(i=0;i<10;i++)
    {
      wait(&numfils);
      if(i==0)
	{
	  printf("Premier : %d \n",WEXITSTATUS(numfils));
	}
      else
	{
	  printf("%dème : %d \n",i+1,WEXITSTATUS(numfils));
	}
    }
  exit(EXIT_SUCCESS);
}
