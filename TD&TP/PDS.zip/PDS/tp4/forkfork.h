typedef void (*func) (int);
void forkfork(func f,int i);
