#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "makeargv.h"

#define AND 1
#define OR 0

int main(int argc, char **argv){
int option,status ,i,j,result, cc;
pid_t pid;
char **cmd;

cc = 0;
j=2;

/*	if (!strcmp(argv[1],"-cc")){
		cc = 1;
		j++;
	}else{
		printf("Erreur : l'option est inconnu ou bien oubli de l'option [-cc]");
	}*/

	/*le traitement du and et le or*/
	if (!strcmp(argv[j-1],"-and")){
		option = AND;
	}else if (!strcmp(argv[j-1],"-or")){
		option = OR;
	}else {
		printf("Erreur : l'option est inconnue , ou oubli de l'option [-and|-or]\n");
	}
	/*creation des processur*/
	for(i=j; i<argc;i++){
		switch(pid = fork()) {
			case -1 : 
				printf("Erreur sur la creation de processus");
				exit(EXIT_FAILURE);
			case 0 :
			    	makeargv(argv[i]," \t",&cmd);
			    	execvp(cmd[0],cmd);
			    	freeargv(cmd);
			default :;
		}
	}

	/*test sur les processus fils*/
	for(i=j ; i<argc ; i++) {
		pid = wait(&status);
   		printf(" status = %d\n",status);
		
		if (option == AND) 
			result = result && (!status);
		else if (option == OR) 
			result = result || (!status); 
		if (pid!=-1)printf("processus %d terminé \n",pid);

		if(result) 
			printf("SUCCES\n");
		else 
			printf("ECHEC\n");
		return(result);
	}
}
