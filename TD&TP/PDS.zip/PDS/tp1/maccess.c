#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <unistd.h>
#include <errno.h>

#define erreur1 "Le droit d'accés demandé au fichier n'est pas positionné "
#define erreur2 "Le fichier n'existe pas "
#define erreur3 "Une des composantes du nom de fichier n'est pas un repertoire "
#define erreur4 "Une des composantes du nom du fichier est trop longue "
#define erreur5 "Le nom du fichier est trop long "
#define erreur6 "Le nom du fichier comporte trop de liens symboliques "
#define erreur7 "Autre erreur"


int main(int argc,char *argv[]){

  char *mode;
  char *fichier;
  int val;
  int verbose = 0;

  if(argc<3){
    printf("erreur pas assez de parametres\n");
    exit(EXIT_FAILURE);
  }

  if(argc>3){
    printf("trop de parametres\n");
    exit(EXIT_FAILURE);
  }

  if (argc = 3) {
    mode=argv[1];
    fichier=argv[2];

  if(*mode!= '-'){        /* attention pour spécifier le mode, il faut mettre le - obligatoire */
    printf("il manque le - obligatoire pour spécifier le mode \n");
    exit(EXIT_FAILURE);
  }
  else{
    *mode++;
  }
  

  while(*mode!=0){

    switch(*mode){

    case 'v': 
      verbose=1;
      break;

    case 'w':                            /* si val==-1 alors sa ne sert a rien de refaire des access vu qu'il y a erreur */
      if(val!=-1){
      val=access(fichier,W_OK);
      }
      break;

    case 'r':
      if(val!=-1){
      val=access(fichier,R_OK);
      }
      break;
            
    case 'x':
      if(val!=-1){
      val=access(fichier,X_OK);
      }
      break;
   
    default :  
      printf("%s\n",erreur7); 
      exit(EXIT_FAILURE);
    }
    *mode++;
  }

  /*a partir d'ici, il faut repertorie les erreurs */  
  
  if((val==-1)&&(verbose==1)){

    switch(errno){

    case ENOENT: 
      printf("%s\n",erreur2);
      exit(EXIT_FAILURE);
      break;

    case EACCES :
      printf("%s\n",erreur1);
      exit(EXIT_FAILURE);
      break;

    case ENOTDIR:
      printf("%s\n",erreur3);
      exit(EXIT_FAILURE);
      break;

    case ENAMETOOLONG:
      printf("%s\n",erreur5);
      exit(EXIT_FAILURE);
      break;

    case ELOOP:
      printf("%s\n",erreur6);
      exit(EXIT_FAILURE);
      break;

    default: 
      printf("%s\n",erreur7);
      exit(EXIT_FAILURE);
    }
  }

  if(val==-1){         /* au cas ou on ne met pas verbose */
    exit(EXIT_FAILURE);
  }
  else{
    exit(EXIT_SUCCESS);
  }
  return 0;


  }

}
