TP PDS

COMPTE-RENDU :

	1-Comment répertorier les erreurs .
	
		En utilisant le man sur access, on peut déjà trouver quelles erreurs correspondent à celles du TP.
		Par exemple, on remarque  dans le man que 
			-> ELOOP correspond à l'erreur 6 du TP .
			-> EACCES correspond à l'erreur 1 du TP.
			-> ENAMETOOLONG correspond à l'erreur 5.
			-> ENOENT à l'erreur 2.
			-> ENOTDIR à l'erreur 3.
			-> Autre erreur à l'erreur 7.

		
	2-la trace des essais effectués sur la commande maccess est dans le fichier "trace.txt".


	3-Un petit soucis :   le fichier texte trace ne peut être lu par un éditeur de texte , il faut utiliser la commande "cat" pour
			      l'afficher.