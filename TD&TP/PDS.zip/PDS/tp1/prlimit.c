#include <stdio.h>
#include <limits.h>
#include <unistd.h>

int main(int argc,char *argv[]) {

  printf("la valeur de NAME_MAX : %d \n",NAME_MAX);
  printf("la valeur de PATH_MAX : %d \n",PATH_MAX);
  return 0;

}
