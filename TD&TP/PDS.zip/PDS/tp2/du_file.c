#include <stdlib.h>
#include <stdio.h>

#include <sys/types.h>
#include <sys/stat.h>

#include <dirent.h>

#include <string.h>
#include <limits.h>
#include <unistd.h>
#include <errno.h>

#include <assert.h>

#include "tools.h"

#define N 100 /*nombre de liens symboliques par branche*/

static int opt_follow_links = 0;
static int opt_apparent_size = 0;

int du_File(const char  *pathname){
  int compteur=0;
  struct stat st;
  int status;
  if((status = lstat(pathname, &st))){
    perror("could not open ");
  }
  
  
  if(S_ISREG(st.st_mode)){
    return opt_apparent_size?st.st_size:st.st_blocks;
  }

  if(S_ISDIR(st.st_mode)){    
    DIR *rep;
    struct dirent *entree;
    int size = opt_apparent_size?st.st_size:st.st_blocks;
    if(!(rep=opendir(pathname))){
      perror("could not open ");
      return 0;
    }
    while((entree = readdir(rep))){
      char *name = malloc(PATH_MAX+1);
      if(! valid_name(entree->d_name))
	continue;/*on fait rien*/
      snprintf(name, PATH_MAX,"%s/%s",pathname,entree->d_name);
      size += du_File(name); 
    }
    return size;
  }
  if(S_ISLNK(st.st_mode)){
    
    int size = opt_apparent_size?st.st_size:st.st_blocks;
    char path[PATH_MAX+1];
    int len;
    
    compteur++;
    if(compteur >= N){
      printf("%s %d %s\n", "plus de", N, "liens symboliques dans une même branche");
      return 0;
    }    
    
    len = readlink(pathname, path, PATH_MAX);
    if(len != -1)
      path[len] = '\0';
    size += du_File(path);
    return opt_follow_links?st.st_size:st.st_blocks;
    
  }
  exit(EXIT_SUCCESS);
}

void usage(){
  
  printf("%s\n","Usage: mdu [-ld] fichier");

}





int main(int argc, char **argv){
  int i;

  switch (argc) {
  case 2:
    du_File(argv[1]);
    break;
  case 3:
    if(argv[1][0] != '-'){
      printf("arguments non valides \n");
      usage();
    }else{
      for(i = 1; i < strlen(argv[1]); i++){
	switch(argv[1][i]){
	
	case('b'):opt_apparent_size = 1;
          break;
	
	case('L'):opt_follow_links = 1;
	  break;

	default:
	  break;
	}
      }

      for(i=2;i<argc;i++){
	printf("%d \t %s\n",du_File(argv[i]),argv[i]);
      }
      
    }
    break;
  default :
    printf("pas assez d'arguments\n");
    usage();
    exit(EXIT_FAILURE);
  }
  exit(EXIT_SUCCESS);
}





