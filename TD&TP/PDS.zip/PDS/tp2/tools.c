#include <string.h>
int valid_name(char *name){
  return strcmp(name, ".")&&strcmp(name,"..");
}
