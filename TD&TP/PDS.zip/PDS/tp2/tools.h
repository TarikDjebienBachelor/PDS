extern int valid_name(char *);
