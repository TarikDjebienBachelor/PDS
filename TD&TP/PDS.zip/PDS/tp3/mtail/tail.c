#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <sys/stat.h>

#define BUFSIZE 1024


static int define_file = 1;
static int caracteres_insuffisants = 0;
static int nombres_lignes = 10;


int nligne_buf(char *buf, int bufsize){
  int i=0, result=0;
  for(i=0; i < BUFSIZE; i++){
    if(buf[i] == '\n')
      result++;
  }
  return result;
}




void tail_before_pos(int fd, int nlignes){
  int nchar,status,lignes,n=0,i;
  char buf[BUFSIZE];
  status = caracteres_insuffisants?lseek(fd,-1,SEEK_CUR):lseek(fd,-BUFSIZE,SEEK_CUR);
  if(caracteres_insuffisants)
    assert(status != -1);
  if ((!caracteres_insuffisants)&&(status == -1)){
    caracteres_insuffisants = 1;
    /*status = lseek(fd,BUFSIZE,SEEK_CUR);*//*on ramene le curseur à sa position anterieure*/
    status = lseek(fd,-1,SEEK_CUR);/* on pose le curseur à un octet en arriere*/
    assert(status != -1);
  }
  if((nchar = caracteres_insuffisants?read(fd,buf,1):read(fd,buf,BUFSIZE)) > 0){
    assert(nchar >= 0);
    status = caracteres_insuffisants?lseek(fd,-1,SEEK_CUR):lseek(fd,-BUFSIZE,SEEK_CUR);
    assert(status != -1);
    if ((lignes = nligne_buf(buf, nchar)) > nlignes){
      for(i=0;i<nchar;i++){
	
	if(buf[i] == '\n')
	  n++;
	if(n >= (lignes-nlignes))
	  printf("%c",buf[i+1]);
	
      }
    }
    else{
      tail_before_pos(fd,nlignes-lignes);
      fprintf(stdout,"%s",buf);
    }
  }
}


void tail_stdin(int fd, int nlignes){
  int nchar, lignes,n=0,i;
  char buf[BUFSIZE];
 
  if((nchar = read(fd,buf,BUFSIZE)) > 0){
    assert(nchar >= 0);
    if ((lignes = nligne_buf(buf, nchar)) > nlignes){
      for(i=0;i<nchar;i++){
	
	if(buf[i] == '\n')
	  n++;

	if(n >= (lignes-nlignes))
	  printf("%c",buf[i]);
	
      }
    }
    else{
      fprintf(stdout,"%s",buf);
      tail_stdin(fd,nlignes-lignes);
      
    }
  }

}


void tail(const char *file_name, int nlignes){
  int fd, status;
  if (!define_file){
    fd = STDIN_FILENO;
    /*status = lseek(fd,0,SEEK_END);*/
    tail_stdin(fd,nlignes);
  }
  else{
    fd = open(file_name,O_RDONLY);
    status = lseek(fd,0,SEEK_END);
    assert(status != -1);
    tail_before_pos(fd,nlignes);
  }
}



int main(int argc, char **argv){
  char *file;
  switch(argc){
  case 1 :
    define_file = 0;
    break;
  case 2:
    file = argv[1];
    break;
  case 3:
    if((argv[1][0] == '-')&&(argv[1][1] == 'n')){
      nombres_lignes = atoi(argv[2]);
      define_file = 0;
    }
    else
      exit(EXIT_FAILURE);
    break;
  case 4:
    if((argv[1][0] == '-')&&(argv[1][1] == 'n')){
      nombres_lignes = atoi(argv[2]);
      file = argv[3];
    }
    else
      exit(EXIT_FAILURE);
    break;
  default:
    break;
  }
    
  tail(file,nombres_lignes);
  exit(EXIT_SUCCESS);
}
