#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <assert.h>


int main (int argc , char **argv) {
  char *filename;
  int fd , status , nb , de ;
  
  filename = argv[1];
  nb = atoi(argv[2]);
  de = atoi(argv[3]);


  fd = open(filename,O_RDONLY | O_WRONLY);
  status = lseek(fd,nb,de);
  if (status == -1) {
    printf("non seekable file !! \n");
    exit(EXIT_FAILURE);
  }
    printf("seekable file \n");
    exit(EXIT_SUCCESS);

}